import React, { useState, useEffect } from "react";
import Header from "./components/Header.jsx";
import URLChecker from "./components/URLChecker.jsx";
import ScanHistory from "./components/ScanHistory.jsx";

export default function App() {
  const [history, setHistory] = useState([]);

  const loadHistory = async () => {
    try {
      const res = await fetch("/api/history");
      const data = await res.json();
      setHistory(data.history || []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadHistory();
  }, []);

  return (
    <div className="min-h-screen px-4 py-8 max-w-5xl mx-auto">
      <Header />
      <URLChecker onScanned={loadHistory} />
      <ScanHistory history={history} onClear={loadHistory} />
      <footer className="text-center text-xs text-gray-500 mt-12">
        Built with ❤️ by <span className="text-cyber-accent">Aman Savita</span> · Cybersecurity + ML
      </footer>
    </div>
  );
}
