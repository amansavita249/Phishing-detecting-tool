import React from "react";

export default function ScanHistory({ history, onClear }) {
  const clear = async () => {
    await fetch("/api/history", { method: "DELETE" });
    onClear?.();
  };

  return (
    <section className="mt-10 bg-cyber-panel/60 border border-white/10 rounded-2xl p-6 backdrop-blur">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-white">📜 Scan History</h2>
        {history.length > 0 && (
          <button
            onClick={clear}
            className="text-xs text-cyber-danger border border-cyber-danger/40 px-3 py-1 rounded hover:bg-cyber-danger/10"
          >
            Clear
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <p className="text-gray-500 text-sm">No scans yet. Try checking a URL above.</p>
      ) : (
        <ul className="space-y-2">
          {history.map((item, i) => {
            const isPhish = item.prediction === "Phishing";
            return (
              <li
                key={i}
                className="flex justify-between items-center p-3 bg-black/30 border border-white/5 rounded-lg"
              >
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-white truncate">{item.url}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(item.timestamp).toLocaleString()}
                  </p>
                </div>
                <div className="ml-3 text-right">
                  <span
                    className={`text-xs font-semibold ${
                      isPhish ? "text-cyber-danger" : "text-cyber-accent"
                    }`}
                  >
                    {item.prediction}
                  </span>
                  <p className="text-xs text-gray-400">{item.phishing_score}%</p>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
