import React, { useState } from "react";

export default function URLChecker({ onScanned }) {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const handleCheck = async (e) => {
    e.preventDefault();
    if (!url.trim()) return;
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const res = await fetch("/api/check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed");
      setResult(data);
      onScanned?.();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const isPhish = result?.prediction === "Phishing";

  return (
    <section className="bg-cyber-panel/60 border border-white/10 rounded-2xl p-6 backdrop-blur">
      <form onSubmit={handleCheck} className="flex flex-col md:flex-row gap-3">
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://example.com/login"
          className="flex-1 bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-cyber-accent"
        />
        <button
          type="submit"
          disabled={loading}
          className="px-6 py-3 bg-cyber-accent text-black font-semibold rounded-lg hover:opacity-90 disabled:opacity-50"
        >
          {loading ? "Scanning..." : "🔍 Scan URL"}
        </button>
      </form>

      {error && <p className="mt-4 text-cyber-danger">⚠️ {error}</p>}

      {result && (
        <div className="mt-6 space-y-4">
          <div
            className={`p-4 rounded-lg border ${
              isPhish
                ? "border-cyber-danger/40 bg-cyber-danger/10"
                : "border-cyber-accent/40 bg-cyber-accent/10"
            }`}
          >
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-400">Prediction</p>
                <p
                  className={`text-2xl font-bold ${
                    isPhish ? "text-cyber-danger" : "text-cyber-accent"
                  }`}
                >
                  {isPhish ? "⚠️ Phishing" : "✅ Legitimate"}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-400">Phishing Score</p>
                <p className="text-3xl font-bold text-white">
                  {result.phishing_score}%
                </p>
              </div>
            </div>
            <div className="mt-3 h-2 bg-black/40 rounded-full overflow-hidden">
              <div
                className={`h-full ${isPhish ? "bg-cyber-danger" : "bg-cyber-accent"}`}
                style={{ width: `${result.phishing_score}%` }}
              />
            </div>
          </div>

          <details className="bg-black/30 border border-white/10 rounded-lg p-4">
            <summary className="cursor-pointer text-cyber-accent text-sm">
              🧬 View Extracted Features
            </summary>
            <pre className="mt-3 text-xs text-gray-300 overflow-auto">
              {JSON.stringify(result.features, null, 2)}
            </pre>
          </details>
        </div>
      )}
    </section>
  );
}
