import React from "react";

export default function Header() {
  return (
    <header className="text-center mb-10">
      <div className="inline-block px-4 py-1 rounded-full border border-cyber-accent/30 text-cyber-accent text-xs mb-4">
        🛡️ CYBERSECURITY · MACHINE LEARNING
      </div>
      <h1 className="text-4xl md:text-5xl font-bold text-white">
        Phishing <span className="text-cyber-accent">Detection</span> Tool
      </h1>
      <p className="text-gray-400 mt-3">
        Suspicious URLs ko AI ke through detect karo — real-time phishing score ke saath.
      </p>
    </header>
  );
}
