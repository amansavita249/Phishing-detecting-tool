# ==========================================================
# ML Model Training Script
# Created By: Aman Savita
# Model: RandomForestClassifier
# ==========================================================

import os
import sys
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report

# Backend folder ko path me add karo (feature_extractor import karne ke liye)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(BASE_DIR, "..", "backend"))

from feature_extractor import extract_features, features_to_vector, FEATURE_ORDER

DATASET_PATH = os.path.join(BASE_DIR, "..", "dataset", "sample_urls.csv")
MODEL_PATH = os.path.join(BASE_DIR, "phishing_model.pkl")


def main():
    print("[*] Loading dataset...")
    df = pd.read_csv(DATASET_PATH)
    print(f"    Total samples: {len(df)}")

    # Har URL se features nikalo
    print("[*] Extracting features...")
    X = [features_to_vector(extract_features(u)) for u in df["url"]]
    y = df["label"].astype(int).tolist()

    # Train-Test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Model train karo
    print("[*] Training RandomForestClassifier...")
    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)

    # Evaluate
    preds = model.predict(X_test)
    acc = accuracy_score(y_test, preds)
    print(f"[OK] Accuracy: {acc * 100:.2f}%")
    print(classification_report(y_test, preds, target_names=["Legitimate", "Phishing"]))

    # Model save karo
    joblib.dump(model, MODEL_PATH)
    print(f"[OK] Model saved at: {MODEL_PATH}")


if __name__ == "__main__":
    main()
