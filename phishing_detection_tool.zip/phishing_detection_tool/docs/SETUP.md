# 🛠️ Setup Guide

## Prerequisites
- Python 3.10+
- Node.js 18+
- npm or pnpm

## Step 1 — Clone
```bash
git clone <your-repo-url>
cd phishing_detection_tool
```

## Step 2 — Backend
```bash
cd backend
pip install -r requirements.txt
cd ..
python ml_model/train_model.py    # trains and saves ml_model/phishing_model.pkl
cd backend
python app.py                     # starts API on :5000
```

## Step 3 — Frontend
```bash
cd frontend
npm install
npm run dev                       # opens UI on :5173
```

## Step 4 — Test
Open http://localhost:5173 → paste a URL → click Scan.

## Deployment Tips
- **Backend** → Render / Railway (use `gunicorn app:app`)
- **Frontend** → Vercel / Netlify (build cmd: `npm run build`, output: `dist`)
- Update API base URL in `vite.config.js` proxy or use `VITE_API_URL` env var.
