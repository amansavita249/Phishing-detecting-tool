# 🛡️ Phishing Detection Tool

**Created By:** Aman Savita
**Tech Stack:** Python · Flask · Scikit-Learn · React · TailwindCSS · Machine Learning · Cybersecurity

A production-ready, portfolio-ready **Phishing URL Detection** tool that uses Machine Learning + URL feature extraction to predict whether a URL is **Phishing** or **Legitimate**.

---

## 🚀 Features

- 🔍 URL feature extraction (length, special chars, IP usage, HTTPS, suspicious words, etc.)
- 🤖 Machine Learning model (Random Forest Classifier)
- 📊 Phishing Score (0–100%) detection
- 🕵️ Cybersecurity themed React + Tailwind UI
- 🧾 Scan History feature
- 🌐 Flask REST API backend
- 📁 Sample dataset included
- 💬 Comments in simple Hindi-English (Hinglish)
- ✅ Ready for GitHub upload, Portfolio, Deployment

---

## 📂 Project Structure

```
phishing_detection_tool/
├── backend/                # Flask API + ML inference
│   ├── app.py
│   ├── feature_extractor.py
│   └── requirements.txt
├── ml_model/               # Training script + saved model
│   ├── train_model.py
│   └── phishing_model.pkl  # generated after training
├── dataset/
│   └── sample_urls.csv
├── frontend/               # React + Tailwind UI
│   ├── package.json
│   ├── index.html
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── index.css
│       └── components/
│           ├── URLChecker.jsx
│           ├── ScanHistory.jsx
│           └── Header.jsx
├── assets/
│   └── logo.svg
├── docs/
│   └── SETUP.md
├── requirements.txt
├── .gitignore
└── README.md
```

---

## ⚙️ Setup Instructions

### 1️⃣ Backend (Python + Flask)

```bash
cd backend
pip install -r requirements.txt
# Train model first (creates ml_model/phishing_model.pkl)
python ../ml_model/train_model.py
python app.py
```

Backend runs at: `http://localhost:5000`

### 2️⃣ Frontend (React + Vite)

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at: `http://localhost:5173`

---

## 🧪 API Usage

**POST** `/api/check`
```json
{ "url": "http://example.com/login" }
```

**Response:**
```json
{
  "url": "http://example.com/login",
  "prediction": "Legitimate",
  "phishing_score": 23.5,
  "features": { "...": "..." }
}
```

---

## 📦 Deployment

- **Backend:** Render / Railway / PythonAnywhere
- **Frontend:** Vercel / Netlify
- **Full Stack:** Docker (Dockerfile-ready structure)

---

## 👨‍💻 Author

**Aman Savita** — Cybersecurity & ML Enthusiast

> ⭐ If you like this project, give it a star on GitHub!
