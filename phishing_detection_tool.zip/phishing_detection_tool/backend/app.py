# ==========================================================
# Flask Backend API - Phishing Detection Tool
# Created By: Aman Savita
# ==========================================================

import os
import joblib
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS

from feature_extractor import extract_features, features_to_vector

# Flask app initialize karo
app = Flask(__name__)
CORS(app)  # React frontend se connect karne ke liye

# Model load karo (training ke baad bana hua)
MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "ml_model", "phishing_model.pkl")

model = None
if os.path.exists(MODEL_PATH):
    model = joblib.load(MODEL_PATH)
    print("[OK] Model loaded successfully")
else:
    print("[WARN] Model file not found. Run: python ml_model/train_model.py")

# In-memory scan history (production me DB use karo)
scan_history = []


@app.route("/", methods=["GET"])
def home():
    """Health check endpoint."""
    return jsonify({
        "status": "running",
        "project": "Phishing Detection Tool",
        "author": "Aman Savita",
        "model_loaded": model is not None,
    })


@app.route("/api/check", methods=["POST"])
def check_url():
    """Main endpoint - URL check karta hai."""
    data = request.get_json(silent=True) or {}
    url = (data.get("url") or "").strip()

    if not url:
        return jsonify({"error": "URL is required"}), 400

    if model is None:
        return jsonify({"error": "Model not loaded. Train it first."}), 503

    # Features extract karo
    features = extract_features(url)
    vector = features_to_vector(features)

    # Predict karo
    prediction = int(model.predict([vector])[0])  # 1 = phishing, 0 = legit
    proba = model.predict_proba([vector])[0]
    phishing_score = round(float(proba[1]) * 100, 2)

    result = {
        "url": url,
        "prediction": "Phishing" if prediction == 1 else "Legitimate",
        "phishing_score": phishing_score,
        "features": features,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }

    # History me add karo (latest 50)
    scan_history.insert(0, result)
    del scan_history[50:]

    return jsonify(result)


@app.route("/api/history", methods=["GET"])
def history():
    """Scan history return karta hai."""
    return jsonify({"history": scan_history})


@app.route("/api/history", methods=["DELETE"])
def clear_history():
    """History clear karta hai."""
    scan_history.clear()
    return jsonify({"status": "cleared"})


if __name__ == "__main__":
    # Dev server start karo
    app.run(host="0.0.0.0", port=5000, debug=True)
