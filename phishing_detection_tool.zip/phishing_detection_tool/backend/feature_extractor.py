# ==========================================================
# Feature Extractor - URL ke andar se features nikalta hai
# Created By: Aman Savita
# ==========================================================

import re
from urllib.parse import urlparse

# Suspicious keywords jo aksar phishing URLs me hote hain
SUSPICIOUS_WORDS = [
    "login", "verify", "secure", "account", "update", "bank",
    "confirm", "signin", "password", "ebay", "paypal", "free",
    "bonus", "gift", "click", "win"
]


def extract_features(url: str) -> dict:
    """URL se numeric features extract karta hai (ML model ke liye)."""
    parsed = urlparse(url if "://" in url else "http://" + url)
    hostname = parsed.hostname or ""
    path = parsed.path or ""

    features = {
        # URL length - lambi URLs mostly suspicious hoti hain
        "url_length": len(url),
        # Hostname length
        "hostname_length": len(hostname),
        # Number of dots - jyada dots = suspicious
        "num_dots": url.count("."),
        # Number of hyphens
        "num_hyphens": url.count("-"),
        # @ symbol ka use - phishing me common
        "num_at": url.count("@"),
        # Question marks
        "num_question": url.count("?"),
        # Equal signs
        "num_equals": url.count("="),
        # Underscores
        "num_underscore": url.count("_"),
        # Slashes
        "num_slash": url.count("/"),
        # Digits in URL
        "num_digits": sum(c.isdigit() for c in url),
        # HTTPS use hua ya nahi (1 = yes, 0 = no)
        "has_https": 1 if parsed.scheme == "https" else 0,
        # IP address direct use kiya hai kya
        "has_ip": 1 if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", hostname) else 0,
        # Suspicious word count
        "suspicious_words": sum(1 for w in SUSPICIOUS_WORDS if w in url.lower()),
        # Path length
        "path_length": len(path),
        # Subdomains count
        "num_subdomains": max(0, hostname.count(".") - 1),
    }
    return features


# Feature order (same order during train + predict)
FEATURE_ORDER = [
    "url_length", "hostname_length", "num_dots", "num_hyphens", "num_at",
    "num_question", "num_equals", "num_underscore", "num_slash", "num_digits",
    "has_https", "has_ip", "suspicious_words", "path_length", "num_subdomains",
]


def features_to_vector(features: dict) -> list:
    """Dict ko list me convert karta hai - model ke input ke liye."""
    return [features[k] for k in FEATURE_ORDER]
